import numpy as np
import struct
import os
from sklearn.cluster import KMeans

class IVFIndexBuilder:
    def __init__(self, n_clusters=64, dim=96):
        self.n_clusters = n_clusters
        self.dim = dim
        self.centroids = None
        self.ivf_lists = None
        
    def load_data(self, data_path):
        """加载数据"""
        with open(data_path, 'rb') as f:
            n = struct.unpack('I', f.read(4))[0]
            d = struct.unpack('I', f.read(4))[0]
            
            data = np.zeros((n, d), dtype=np.float32)
            for i in range(n):
                vec = struct.unpack('f' * d, f.read(4 * d))
                data[i] = vec
                
        print(f"Loaded data: {n} vectors, {d} dimensions")
        return data
    
    def build_index(self, data):
        """构建IVF索引"""
        print("Building IVF index...")
        
        # 1. K-means聚类生成簇中心
        print(f"Running K-means with {self.n_clusters} clusters...")
        kmeans = KMeans(n_clusters=self.n_clusters, random_state=42, n_init=5)
        cluster_labels = kmeans.fit_predict(data)
        self.centroids = kmeans.cluster_centers_.astype(np.float32)
        
        # 2. 构建倒排索引
        print("Building inverted lists...")
        self.ivf_lists = [[] for _ in range(self.n_clusters)]
        
        for i, label in enumerate(cluster_labels):
            self.ivf_lists[label].append(i)
            
        # 转换为numpy数组以便保存
        for i in range(self.n_clusters):
            self.ivf_lists[i] = np.array(self.ivf_lists[i], dtype=np.int32)
            
        print(f"Index built successfully!")
        print(f"Cluster sizes: min={min(len(lst) for lst in self.ivf_lists)}, "
              f"max={max(len(lst) for lst in self.ivf_lists)}, "
              f"avg={np.mean([len(lst) for lst in self.ivf_lists]):.1f}")
    
    def save_index(self, output_dir="files"):
        """保存索引到文件"""
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
            
        # 保存簇中心
        centroids_path = os.path.join(output_dir, "centroids.bin")
        with open(centroids_path, 'wb') as f:
            f.write(struct.pack('I', self.n_clusters))  # 簇数量
            f.write(struct.pack('I', self.dim))         # 维度
            for centroid in self.centroids:
                for val in centroid:
                    f.write(struct.pack('f', val))
        print(f"Centroids saved to {centroids_path}")
        
        # 保存倒排索引
        ivf_path = os.path.join(output_dir, "ivf_lists.bin")
        with open(ivf_path, 'wb') as f:
            for i in range(self.n_clusters):
                list_size = len(self.ivf_lists[i])
                f.write(struct.pack('I', list_size))  # 当前簇的大小
                for idx in self.ivf_lists[i]:
                    f.write(struct.pack('i', idx))    # 数据点索引
        print(f"Inverted lists saved to {ivf_path}")

def main():
    # 构建索引
    builder = IVFIndexBuilder(n_clusters=2048, dim=96)
    
    # 加载数据
    data = builder.load_data("anndata/DEEP100K.base.100k.fbin")
    
    # 构建索引
    builder.build_index(data)
    
    # 保存索引
    builder.save_index("files")
    
    print("Index building completed!")

if __name__ == "__main__":
    main()