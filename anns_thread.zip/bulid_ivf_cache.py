import numpy as np
import struct, os
from sklearn.cluster import KMeans


class IVFIndexBuilder:
    def __init__(self, n_clusters=64, dim=96):
        self.n_clusters = n_clusters
        self.dim = dim
        self.centroids = None
        self.ivf_lists = None          # list[list[int]]
        self.reorder_indices = None    # 重排后的全局下标

    # -------------------------------------------------------------
    # 1. 读取 fbin / fvecs
    # -------------------------------------------------------------
    @staticmethod
    def load_fbin(path):
        """读取 *.fbin / *.fvecs 格式 (开头两个 uint32: n, d)"""
        with open(path, "rb") as f:
            n, d = struct.unpack("II", f.read(8))
            vecs = np.fromfile(f, dtype=np.float32, count=n * d)
        vecs = vecs.reshape(n, d)
        print(f"[load] {path}  ->  {n} x {d}")
        return vecs

    # -------------------------------------------------------------
    # 2. K-Means & 倒排表
    # -------------------------------------------------------------
    def build_index(self, data):
        print(f"[K-Means] k={self.n_clusters}   n={len(data)}   d={self.dim}")
        kmeans = KMeans(
            n_clusters=self.n_clusters,
            n_init=5,
            random_state=42,
            max_iter=300,
            verbose=0,
        )
        labels = kmeans.fit_predict(data)
        self.centroids = kmeans.cluster_centers_.astype(np.float32)

        # 倒排表（list of numpy int32）
        self.ivf_lists = [[] for _ in range(self.n_clusters)]
        for idx, lb in enumerate(labels):
            self.ivf_lists[lb].append(idx)
        self.ivf_lists = [np.asarray(lst, dtype=np.int32) for lst in self.ivf_lists]

        print(
            f"[build] done.  min/avg/max size = "
            f"{min(len(l) for l in self.ivf_lists)}/"
            f"{np.mean([len(l) for l in self.ivf_lists]):.1f}/"
            f"{max(len(l) for l in self.ivf_lists)}"
        )

    # -------------------------------------------------------------
    # 3. “内存重排” – 把同簇向量连续存放
    # -------------------------------------------------------------
    def reorder_data_by_cluster(self, data):
        """返回按簇连续排列的新 ndarray 及对应全局下标顺序"""
        assert self.ivf_lists is not None
        self.reorder_indices = np.concatenate(self.ivf_lists)  # shape == (n,)
        data_reordered = data[self.reorder_indices]            # (n, d)
        return data_reordered

    # -------------------------------------------------------------
    # 4. 保存二进制文件
    # -------------------------------------------------------------
    @staticmethod
    def _save_fbin(path, arr):
        """带 header (n, d) 的 float32 数组保存"""
        n, d = arr.shape
        with open(path, "wb") as f:
            f.write(struct.pack("II", n, d))
            arr.astype(np.float32).tofile(f)
        print(f"[save] {path} ({n} x {d})")

    @staticmethod
    def _save_raw_bin(path, arr_uint32):
        """不带 header，纯 uint32 数据保存"""
        with open(path, "wb") as f:
            arr_uint32.astype(np.uint32).tofile(f)
        print(f"[save] {path} (uint32[{arr_uint32.size}])")

    def save_index(self, output_dir="files", base_reordered=None):
        os.makedirs(output_dir, exist_ok=True)

        # 1) 保存簇中心
        cent_path = os.path.join(output_dir, "centroids.bin")
        self._save_fbin(cent_path, self.centroids)

        # 2) 保存按簇重排后的 base 向量
        if base_reordered is not None:
            base_path = os.path.join(output_dir, "clustered_base.bin")
            self._save_fbin(base_path, base_reordered)

        # 3) 保存 offset & length（二进制）
        offset_len = np.zeros((self.n_clusters, 2), dtype=np.uint32)
        offset = 0
        for cid, lst in enumerate(self.ivf_lists):
            offset_len[cid, 0] = offset          # offset
            offset_len[cid, 1] = len(lst)        # length
            offset += len(lst)
        meta_path = os.path.join(output_dir, "ivf_offset_len.bin")
        self._save_raw_bin(meta_path, offset_len)

        # 4) 如有需要，也可以把 reorder_indices 单独保存
        ridx_path = os.path.join(output_dir, "reorder_indices.bin")
        self._save_raw_bin(ridx_path, self.reorder_indices.astype(np.uint32))

        print("[save] all binary files generated.")

# =============================================================
# main
# =============================================================
def main():
    data_path = "anndata/DEEP100K.base.100k.fbin"

    builder = IVFIndexBuilder(n_clusters=1024, dim=96)

    # 1) 读数据
    base_vecs = builder.load_fbin(data_path)

    # 2) 建索引
    builder.build_index(base_vecs)

    # 3) 内存重排
    base_reordered = builder.reorder_data_by_cluster(base_vecs)

    # 4) 写文件（全部二进制）
    builder.save_index("files", base_reordered)

    print("All done!  Centroids, clustered base vectors and IVF metadata are saved in pure binary format.")


if __name__ == "__main__":
    main()