#ifndef IVF_SEARCH_H
#define IVF_SEARCH_H

#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <vector>
#include <atomic>
#include <pthread.h>
#include <thread>
#include <numeric>
#include <functional>

#if defined(__ARM_NEON)
#   include <arm_neon.h>
#endif

#define N_CLUSTERS 1024
#define DIM        96            // 固定 96 维，本文件里全部用常量展开
#define MAX_THREAD 10

/* ===================================================================== */
/*                          简易线程池                                   */
/* ===================================================================== */
class ThreadPool {
public:
    using Task = std::function<void()>;
    explicit ThreadPool(size_t n_threads = 0) : stop(false) {
        if (n_threads == 0) n_threads = MAX_THREAD;
        workers.resize(n_threads);
        pthread_mutex_init(&q_mtx, nullptr);
        pthread_cond_init (&q_cv , nullptr);
        for (size_t i = 0; i < n_threads; ++i)
            pthread_create(&workers[i], nullptr, worker_entry, this);
    }
    ~ThreadPool() {
        pthread_mutex_lock(&q_mtx);  stop = true;
        pthread_cond_broadcast(&q_cv);  pthread_mutex_unlock(&q_mtx);
        for (auto &th: workers) pthread_join(th,nullptr);
        pthread_mutex_destroy(&q_mtx);  pthread_cond_destroy(&q_cv);
    }
    size_t workers_count() const noexcept { return workers.size(); }
    void enqueue(Task&& t){
        pthread_mutex_lock(&q_mtx);
        tasks.emplace(std::move(t));
        pthread_cond_signal(&q_cv);
        pthread_mutex_unlock(&q_mtx);
    }
    void wait_all(){
        pthread_mutex_lock(&q_mtx);
        while(!tasks.empty() || working_cnt>0)
            pthread_cond_wait(&q_cv,&q_mtx);
        pthread_mutex_unlock(&q_mtx);
    }
private:
    static void* worker_entry(void* arg){
        static_cast<ThreadPool*>(arg)->worker_loop(); return nullptr;
    }
    void worker_loop(){
        for(;;){
            pthread_mutex_lock(&q_mtx);
            while(tasks.empty() && !stop) pthread_cond_wait(&q_cv,&q_mtx);
            if(stop && tasks.empty()){ pthread_mutex_unlock(&q_mtx); break; }
            Task task = std::move(tasks.front()); tasks.pop(); ++working_cnt;
            pthread_mutex_unlock(&q_mtx);

            task();   // run

            pthread_mutex_lock(&q_mtx);
            --working_cnt;
            if(tasks.empty() && working_cnt==0) pthread_cond_broadcast(&q_cv);
            pthread_mutex_unlock(&q_mtx);
        }
    }
    std::vector<pthread_t> workers;
    std::queue<Task> tasks;
    pthread_mutex_t q_mtx; pthread_cond_t q_cv;
    size_t working_cnt = 0; bool stop;
};

/* ===================================================================== */
/*                       96-dim 内积的 NEON 优化                          */
/* ===================================================================== */
#if defined(__ARM_NEON)           // arm64 / armv8-a
// 96 = 4 * 24 -> 我们一次处理 16 个 float (4×4) 并手动展开 6 轮
inline float dot96_neon(const float* __restrict a,
                        const float* __restrict b) noexcept
{
    float32x4_t acc0 = vdupq_n_f32(0.f);
    float32x4_t acc1 = acc0, acc2 = acc0, acc3 = acc0;

#   pragma unroll 6
    for (int i = 0; i < 96; i += 4) {
        // 每次加载 4 个元素
        float32x4_t v0 = vld1q_f32(a + i);
        float32x4_t u0 = vld1q_f32(b + i);
        
        // 累加内积
        acc0 = vmlaq_f32(acc0, v0, u0);
    }

    // 汇总结果
    float32x4_t sum = vaddq_f32(acc0, acc1);
    return vaddvq_f32(sum);  // 横向求和
}

#else                                   // fallback：纯标量
inline float dot96_neon(const float* a,const float* b) noexcept {
    float s=0.f;
#   pragma unroll(96)
    for(int i=0;i<96;++i) s += a[i]*b[i];
    return s;
}
#endif

/* ===================================================================== */
/*                              IVFIndex                                 */
/* ===================================================================== */
class IVFIndex {
public:
    IVFIndex()
        : centroids_(nullptr), base_vecs_(nullptr),
          list_offset_(nullptr), list_size_(nullptr),
          reorder_map_(nullptr),
          n_clusters_(N_CLUSTERS), dim_(DIM), ntotal_(0),
          index_loaded_(false), thread_pool_() {}
    ~IVFIndex() { free_memory(); }

    bool load_index(const char* dir = "files") {
        if(index_loaded_) return true;
        return  load_centroids(dir) &&
                load_meta(dir)      &&
                load_reorder_map(dir) &&
                load_base_vectors(dir) &&
                (index_loaded_=true);
    }

    /* --------------------------- 搜索 --------------------------- */
    std::priority_queue<std::pair<float,uint32_t>>
    search(const float* query, size_t topk, int nprobe = 16)   // 默认 nprobe=16
    {
        if(!index_loaded_ && !load_index()){
            std::cerr<<"index load failed\n"; return {};
        }

        /* 1. 选 nprobe 个簇 */
        std::vector<int> sel(nprobe);
        select_clusters_parallel(query,nprobe,sel.data());

        /* 按簇大小降序，先扫大簇 */
        std::sort(sel.begin(), sel.end(),
                  [&](int a,int b){return list_size_[a] > list_size_[b];});

        /* 2. 并行遍历 */
        size_t tnum = thread_pool_.workers_count();
        std::vector< std::priority_queue<std::pair<float,uint32_t>> >
                local_heaps(tnum);

        std::atomic<int> cursor(0);
        for(size_t tid=0; tid<tnum; ++tid){
            thread_pool_.enqueue([&,tid]{
                auto &heap = local_heaps[tid];
                for(;;){
                    int idx = cursor.fetch_add(1,std::memory_order_relaxed);
                    if(idx >= nprobe) break;
                    int cid = sel[idx];
                    int sz  = list_size_[cid];
                    if(sz==0) continue;

                    const float* block = base_vecs_ + (size_t)list_offset_[cid]*dim_;

                    for(int j=0;j<sz;++j){
                        const float* vec = block + (size_t)j*dim_;

                        /* 预取下一条，隐藏内存延迟                */
                        if(j+4 < sz) __builtin_prefetch(vec + 4*dim_, 0, 1);

                        float ip = dot96_neon(query, vec);
                        float dist = 1.f - ip;                 // cosine → distance
                        uint32_t gid = reorder_map_[ list_offset_[cid]+j ];

                        if(heap.size()<topk) heap.emplace(dist,gid);
                        else if(dist < heap.top().first){
                            heap.pop(); heap.emplace(dist,gid);
                        }
                    }
                }
            });
        }
        thread_pool_.wait_all();

        /* 3. merge k-heaps */
        std::priority_queue<std::pair<float,uint32_t>> global_heap;
        for(auto &hp: local_heaps){
            while(!hp.empty()){
                auto e = hp.top(); hp.pop();
                if(global_heap.size()<topk) global_heap.push(e);
                else if(e.first < global_heap.top().first){
                    global_heap.pop(); global_heap.push(e);
                }
            }
        }
        return global_heap;
    }

/* --------------------------------------------------------------------- */
/*                            加载函数                                   */
/* --------------------------------------------------------------------- */
private:
    bool load_centroids(const char* dir){
        std::ifstream fin(std::string(dir)+"/centroids.bin", std::ios::binary);
        if(!fin){ std::cerr<<"open centroids fail\n"; return false; }
        uint32_t n,d;  fin.read((char*)&n,4); fin.read((char*)&d,4);
        if(n!=n_clusters_ || d!=dim_){ std::cerr<<"centroid shape err\n";return false;}
        centroids_ = new float[(size_t)n_clusters_*dim_];
        fin.read((char*)centroids_, (size_t)n_clusters_*dim_*sizeof(float));
        return true;
    }
    bool load_meta(const char* dir){
        std::ifstream fin(std::string(dir)+"/ivf_offset_len.bin", std::ios::binary);
        if(!fin){ std::cerr<<"open meta fail\n"; return false; }
        std::vector<uint32_t> buf((size_t)n_clusters_*2);
        fin.read((char*)buf.data(), buf.size()*sizeof(uint32_t));

        list_offset_ = new uint32_t[n_clusters_];
        list_size_   = new uint32_t[n_clusters_];
        ntotal_ = 0;
        for(int i=0;i<n_clusters_; ++i){
            list_offset_[i]=buf[2*i];
            list_size_  [i]=buf[2*i+1];
            ntotal_ += list_size_[i];
        }
        return true;
    }
    bool load_reorder_map(const char* dir){
        std::ifstream fin(std::string(dir)+"/reorder_indices.bin", std::ios::binary);
        if(!fin){ std::cerr<<"open reorder map fail\n"; return false; }
        reorder_map_ = new uint32_t[ntotal_];
        fin.read((char*)reorder_map_, ntotal_*sizeof(uint32_t));
        return true;
    }
    bool load_base_vectors(const char* dir){
        std::ifstream fin(std::string(dir)+"/clustered_base.bin", std::ios::binary);
        if(!fin){ std::cerr<<"open base fail\n"; return false; }
        uint32_t n,d; fin.read((char*)&n,4); fin.read((char*)&d,4);
        if(d!=dim_||n!=ntotal_){ std::cerr<<"base header mismatch\n";return false;}
        base_vecs_ = new float[(size_t)n*dim_];
        fin.read((char*)base_vecs_, (size_t)n*dim_*sizeof(float));
        return true;
    }

/* --------------------------------------------------------------------- */
/*                    计算距离 / 选簇  (NEON 内积)                       */
/* --------------------------------------------------------------------- */
    void select_clusters_parallel(const float* q,int nprobe,int* out){
        const size_t tnum = thread_pool_.workers_count();
        const int    chunk=32;                // 每线程一次性拉 32 个 centroid
        std::vector<float> scores(n_clusters_);
        std::atomic<int> cursor(0);

        for(size_t t=0;t<tnum;++t){
            thread_pool_.enqueue([&,t]{
                for(;;){
                    int st = cursor.fetch_add(chunk,std::memory_order_relaxed);
                    if(st>=n_clusters_) break;
                    int ed = std::min(st+chunk, N_CLUSTERS);
                    for(int i=st;i<ed;++i)
                        scores[i] = dot96_neon(q, centroids_+ (size_t)i*dim_);
                }
            });
        }
        thread_pool_.wait_all();

        std::vector<int> idx(n_clusters_); std::iota(idx.begin(),idx.end(),0);
        std::partial_sort(idx.begin(), idx.begin()+nprobe, idx.end(),
                          [&](int a,int b){return scores[a]>scores[b];});
        std::memcpy(out, idx.data(), nprobe*sizeof(int));
    }

/* --------------------------------------------------------------------- */
    void free_memory(){
        delete[] centroids_;    delete[] list_offset_;
        delete[] list_size_;    delete[] base_vecs_;
        delete[] reorder_map_;
        centroids_=base_vecs_=nullptr;
        list_offset_=list_size_=reorder_map_=nullptr;
        index_loaded_=false;
    }

/* ----------------------- data member ----------------------- */
    float*      centroids_   = nullptr;
    float*      base_vecs_   = nullptr;
    uint32_t*   list_offset_ = nullptr;
    uint32_t*   list_size_   = nullptr;
    uint32_t*   reorder_map_ = nullptr;
    const int   n_clusters_, dim_;
    uint32_t    ntotal_;
    bool        index_loaded_;
    ThreadPool  thread_pool_;
};

/* ------------------ C-style 简易接口 ------------------ */
static IVFIndex g_ivf;

inline bool preload_index(const char* dir="files"){ return g_ivf.load_index(dir); }

inline std::priority_queue<std::pair<float,uint32_t>>
ivf_search(const float* q,size_t k,int nprobe=16){ return g_ivf.search(q,k,nprobe); }

#endif /* IVF_SEARCH_H */