#ifndef IVF_PQ_SEARCH_H
#define IVF_PQ_SEARCH_H

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iostream>
#include <queue>
#include <vector>

/************  全局参数  ************/
#define N_LIST  1024
#define DIM     96
#define M       16
#define K_PQ    16                  // 建议 ≥ 256
#define DIM_PER_SUBSPACE (DIM / M)

/************  对齐内存  ************/
static inline float* aligned_malloc_f(size_t n) {
    return (float*)std::malloc(n * sizeof(float));  // Using standard malloc
}
static inline void   aligned_free_f(float* p) { std::free(p); }  // Using standard free

/************  索引结构  ************/
struct IVFIndex {
    float*   centroids;                      // [N_LIST, DIM]
    int**    ivf_lists;                      // [N_LIST][list_size]
    int*     list_size;                      // [N_LIST]
    float*   pq_codebooks;                   // [N_LIST, M, K_PQ, DIM_PER_SUBSPACE]
    uint8_t**pq_codes;                       // [N_LIST][list_size * M]
    bool     loaded = false;

    ~IVFIndex() { release(); }

    void release() {
        if (!loaded) return;
        aligned_free_f(centroids);
        aligned_free_f(pq_codebooks);
        delete[] list_size;
        for (int i = 0; i < N_LIST; ++i) {
            delete[] ivf_lists[i];
            aligned_free_f((float*)pq_codes[i]);
        }
        delete[] ivf_lists;
        delete[] pq_codes;
        loaded = false;
    }
};

/************  全局索引实例  ************/
static IVFIndex g_index;

/************  内积计算  ************/
static inline float distance(const float* a, const float* b, int d = DIM) {
    float res = 0.f;
    for (int i = 0; i < d; i++) {
        res += a[i] * b[i];
    }
    return res;
}

/************  读取索引文件  ************/
static bool load_index_from_disk(const std::string& path = "files") {
    if (g_index.loaded) return true;

    /***** 1. centroids *****/
    std::ifstream fin(path + "/centroids.bin", std::ios::binary);
    if (!fin.is_open()) { std::cerr << "open centroids fail\n"; return false; }
    int nlist, dim;
    fin.read((char*)&nlist, 4);  fin.read((char*)&dim, 4);
    assert(nlist == N_LIST && dim == DIM);
    g_index.centroids = aligned_malloc_f((size_t)N_LIST * DIM);
    fin.read((char*)g_index.centroids, sizeof(float) * N_LIST * DIM);
    fin.close();

    /***** 2. ivf lists *****/
    fin.open(path + "/ivf_lists.bin", std::ios::binary);
    if (!fin.is_open()) { std::cerr << "open ivf_lists fail\n"; return false; }
    g_index.ivf_lists = new int*[N_LIST];
    g_index.list_size = new int[N_LIST];
    for (int i = 0; i < N_LIST; ++i) {
        fin.read((char*)&g_index.list_size[i], 4);
        if (g_index.list_size[i]) {
            g_index.ivf_lists[i] = new int[g_index.list_size[i]];
            fin.read((char*)g_index.ivf_lists[i], 4LL * g_index.list_size[i]);
        } else g_index.ivf_lists[i] = nullptr;
    }
    fin.close();

    /***** 3. pq codebook *****/
    fin.open(path + "/pq_codebooks.bin", std::ios::binary);
    int n1, m, kpq, subd;
    fin.read((char*)&n1,4); fin.read((char*)&m,4);
    fin.read((char*)&kpq,4); fin.read((char*)&subd,4);
    assert(n1==N_LIST && m==M && kpq==K_PQ && subd==DIM_PER_SUBSPACE);
    size_t cb_sz = (size_t)N_LIST*M*K_PQ*DIM_PER_SUBSPACE;
    g_index.pq_codebooks = aligned_malloc_f(cb_sz);
    fin.read((char*)g_index.pq_codebooks, cb_sz * sizeof(float));
    fin.close();

    /***** 4. pq codes *****/
    fin.open(path + "/pq_codes.bin", std::ios::binary);
    g_index.pq_codes = new uint8_t*[N_LIST];
    for (int i = 0; i < N_LIST; ++i) {
        int cnt; fin.read((char*)&cnt,4);
        if (cnt) {
            g_index.pq_codes[i] = (uint8_t*)aligned_malloc_f(cnt * M);
            fin.read((char*)g_index.pq_codes[i], cnt * M);
        } else g_index.pq_codes[i] = nullptr;
    }
    fin.close();
    g_index.loaded = true;
    return true;
}

/************  粗搜索 (选择 nprobe 个簇) ************/
static void coarseSearch(const float* q, int nprobe,
                         float* centroid_scores, int* best_ids) {
    for (int i = 0; i < N_LIST; ++i) {
        centroid_scores[i] = distance(q, g_index.centroids + (size_t)i * DIM);
        best_ids[i]        = i;
    }
    std::partial_sort(best_ids, best_ids + nprobe, best_ids + N_LIST,
                      [&](int a, int b) { return centroid_scores[a] > centroid_scores[b]; });
}

/************  精细 PQ 估分  ************/
using Pair = std::pair<float, uint32_t>;      // first=dist, second=id

static void fineSearch(const float* q,
                       const float* centroid_scores,   // q·c_i
                       const int*   probe_ids, int nprobe,
                       int top_p,
                       std::vector<Pair>& out) {

    float dist_tb[M * K_PQ];     // M × K_PQ

    for (int p = 0; p < nprobe; ++p) {
        int cid   = probe_ids[p];
        float qc  = centroid_scores[cid];

        /*--- 构建查表 :  q_sub · codeword  ---*/
        const float* cb_base = g_index.pq_codebooks + (size_t)cid * M * K_PQ * DIM_PER_SUBSPACE;
        for (int m = 0; m < M; ++m) {
            const float* qsub = q + m * DIM_PER_SUBSPACE;
            for (int k = 0; k < K_PQ; ++k) {
                const float* ckw = cb_base + (size_t)m * K_PQ * DIM_PER_SUBSPACE + k * DIM_PER_SUBSPACE;
                dist_tb[m * K_PQ + k] = distance(qsub, ckw, DIM_PER_SUBSPACE);
            }
        }

        /*--- 遍历倒排表 ---*/
        int  L      = g_index.list_size[cid];
        const uint8_t* codes = g_index.pq_codes[cid];
        const int*     ids   = g_index.ivf_lists[cid];

        for (int i = 0; i < L; ++i) {
            float score = qc;                      // 先加 q·c_i
            const uint8_t* code = codes + i * M;
            for (int m = 0; m < M; ++m)
                score += dist_tb[m * K_PQ + code[m]];

            out.emplace_back(-score, ids[i]);     // 负内积 → 距离
        }
    }

    /*--- 只保留 top_p ---*/
    if ((int)out.size() > top_p) {
        std::nth_element(out.begin(), out.begin() + top_p, out.end(),
                         [](const Pair& a, const Pair& b) { return a.first < b.first; });
        out.resize(top_p);
    }
}

/************  对外主函数 (返回与 flat_search 同型) ************/
static std::priority_queue<Pair>
annSearch(float* base, float* query,
          size_t base_number, size_t vecdim,
          size_t top_p, size_t top_k, size_t nprobe) {

    if (!load_index_from_disk()) return {};

    /* 1. coarse */
    std::vector<float> centroid_scores(N_LIST);
    std::vector<int>   probe_ids(N_LIST);
    coarseSearch(query, (int)nprobe, centroid_scores.data(), probe_ids.data());

    /* 2. fine */
    std::vector<Pair> candidates;
    candidates.reserve(top_p * 2);
    fineSearch(query, centroid_scores.data(), probe_ids.data(), (int)nprobe,
               (int)top_p, candidates);

    /* 3. 精确重排 */
    std::priority_queue<Pair> heap;                 // 大顶堆 (dist大在前)
    for (const auto& pr : candidates) {
        uint32_t idx = pr.second;
        float dot = distance(query, base + (size_t)idx * vecdim, vecdim);
        float dist = 1.f - dot;                     // 与 flat_search 同口径

        if (heap.size() < top_k) heap.emplace(dist, idx);
        else if (dist < heap.top().first) { heap.pop(); heap.emplace(dist, idx); }
    }
    return heap;
}

#endif // IVF_PQ_SEARCH_H
