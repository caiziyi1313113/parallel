# build_index.py
#100K条数据
import numpy as np
import struct, os
from sklearn.cluster import KMeans

# === 参数 ===
N_LIST = 1024       # IVF 聚类中心数量
M = 16              # PQ 子空间数量
K_PQ = 8         # 每个子空间聚类中心数
DIM = 96           # 特征维度
DATA_PATH = "anndata/DEEP100K.base.100k.fbin"
SAVE_DIR = "files"
os.makedirs(SAVE_DIR, exist_ok=True)

# === 数据读取 ===
def load_fvecs(filename):
    with open(filename, 'rb') as f:
        n = struct.unpack('i', f.read(4))[0]
        d = struct.unpack('i', f.read(4))[0]
        data = np.fromfile(f, dtype=np.float32, count=n*d).reshape(n, d)
    return data

data = load_fvecs(DATA_PATH)
n, d = data.shape

# === 1. IVF 聚类 ===
#kmeans = KMeans(n_clusters=N_LIST, random_state=0, n_init='auto').fit(data)
#获取聚类中心（centroids），也就是每个簇的中心向量，形状为 (256, 96)。
#labels是每个数据点的聚类编号（label），是一个长度为 n 的整数数组。
#比如 labels[5] = 12 表示第 6 个数据点属于第 12 个聚类中心。
kmeans = KMeans(n_clusters=N_LIST, random_state=0, n_init=10).fit(data)
centroids = kmeans.cluster_centers_.astype(np.float32)
labels = kmeans.labels_

# === 2. 保存倒排表和质心 ===
#写入簇的数量和维度，然后簇的数据centroids.shape = (256, 96)
with open(f"{SAVE_DIR}/centroids.bin", "wb") as f:
    f.write(struct.pack('i', N_LIST))
    f.write(struct.pack('i', d))
    f.write(centroids.tobytes())

print("簇中心保存成功")

#用于保存 每个 IVF 簇的成员索引列表

with open(f"{SAVE_DIR}/ivf_lists.bin", "wb") as f:
    for i in range(N_LIST):
        #细节，转成 np.uint32 是为了节省存储空间（比默认 int64 小一半)
        #找出所有被归类到第 i 个簇的向量下标（也就是原始数据中属于第 i 类的点的编号）。
        ids = np.where(labels == i)[0].astype(np.uint32)
        #写入当前簇中包含的向量数量（一个 int32，占 4 字节）
        f.write(struct.pack('i', len(ids)))
        #入该簇中所有向量的索引（以 uint32 格式序列化为字节流）
        f.write(ids.tobytes())

print("IVF 聚类完成")
# === 3. 计算残差并进行PQ ===
residuals = data - centroids[labels]
assert d % M == 0
sub_dim = d // M

#创建一个 4 维数组，存储每个簇、每个子空间的 PQ 码本（K-means 的簇中心）
pq_codebooks = np.zeros((N_LIST, M, K_PQ, sub_dim), dtype=np.float32)#4维度
#初始化一个列表，存放每个簇中所有残差向量的 PQ 编码（二进制形式），有N_LIST个元素，每个元素是一个列表
pq_codes = [b'' for _ in range(N_LIST)]

for i in range(N_LIST):
    #找出第 i 个簇中所有样本的下标。
    ids = np.where(labels == i)[0]
    if len(ids) == 0:
        continue

    #提取属于该簇的所有残差向量（原始向量 - 所属簇质心）
    vecs = residuals[ids]
    codebook = []
    #码本索引（点的数量，子空间数目）
    code = np.zeros((len(ids), M), dtype=np.uint8)
    #将每个向量分割成 M 个子向量，对第 m 个子向量做 K-means。
    for m in range(M):
        subvecs = vecs[:, m*sub_dim:(m+1)*sub_dim]
        #kmeans = KMeans(n_clusters=N_LIST, random_state=0, n_init=10).fit(data)
        km = KMeans(n_clusters=K_PQ,random_state=0,n_init=10).fit(subvecs)
        #保存 K_PQ 个子空间簇中心到 pq_codebooks[i, m]。
        pq_codebooks[i, m] = km.cluster_centers_
       #用 .predict() 得到每个子向量的聚类编号（0~255），存到编码中
        code[:, m] = km.predict(subvecs)
    pq_codes[i] = code.tobytes()#所以，pq_codes的形状是3维的，第一个维度是簇数，第二个维度是该簇中的样本数，第三个维度是子空间数。

# 保存 PQ 码本
# 簇类中心的数目、子空间的数目、子空间的维度，存入float32[N_LIST][M][K_PQ][sub_dim] 但是没有子空间的聚类中心数目  # 所有 PQ 簇中心
with open(f"{SAVE_DIR}/pq_codebooks.bin", "wb") as f:
    # 写入完整的维度信息：N_LIST, M, K_PQ, sub_dim
    f.write(struct.pack('iiii', N_LIST, M, K_PQ, sub_dim))
    f.write(pq_codebooks.tobytes())

print("码本构建成功")
# 保存 PQ 编码
#将 每个簇中所有向量的 PQ 编码结果 按照簇（IVF bucket）分别保存到二进制文件 pq_codes.bin 中
#先存入该簇中 PQ 编码向量的个数，再存入该簇中所有向量的 PQ 编码（二进制形式）
with open(f"{SAVE_DIR}/pq_codes.bin", "wb") as f:
    for i in range(N_LIST):
        # 直接写入该簇的样本数量（而非计算字节长度）
        sample_count = len(np.where(labels == i)[0])
        f.write(struct.pack('i', sample_count))
        f.write(pq_codes[i])

print("码本索引构建成功")