#ifndef IVF_SEARCH_H
#define IVF_SEARCH_H

#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <vector>
#include <thread>
#include <mutex>
#include <cassert>

#define N_CLUSTERS 1024
#define DIM        96
#define NUM_THREADS 11          // 静态线程个数（可按机器核数调整）

class IVFIndex {
private:
    /******************** 索引数据 ********************/
    float* centroids;          // [N_CLUSTERS * DIM]
    int**  ivf_lists;          // 倒排表，每行存 base 中向量的下标
    int*   list_sizes;         // 每个簇的元素个数
    int    n_clusters;
    int    dim;
    bool   index_loaded;

public:
    /******************** 构造 & 析构 ********************/
    IVFIndex() :
        centroids(nullptr), ivf_lists(nullptr), list_sizes(nullptr),
        n_clusters(N_CLUSTERS), dim(DIM), index_loaded(false) {}

    ~IVFIndex() { free_memory(); }

    /******************** 资源释放 ********************/
    void free_memory() {
        delete[] centroids;  centroids  = nullptr;
        if (ivf_lists) {
            for (int i = 0; i < n_clusters; ++i) delete[] ivf_lists[i];
            delete[] ivf_lists;
            ivf_lists = nullptr;
        }
        delete[] list_sizes; list_sizes = nullptr;
        index_loaded = false;
    }

    /******************** 加载索引 ********************/
    bool load_index(const char* dir = "files") {
        if (index_loaded) return true;

        char c_path[256], l_path[256];
        snprintf(c_path, sizeof(c_path), "%s/centroids.bin" , dir);
        snprintf(l_path, sizeof(l_path), "%s/ivf_lists.bin", dir);

        return  load_centroids(c_path) && load_ivf_lists(l_path)
             ? (index_loaded = true)
             : false;
    }

private:
    bool load_centroids(const char* path) {
        std::ifstream fi(path, std::ios::binary);
        if (!fi) { std::cerr << "open " << path << " failed\n"; return false; }

        int file_nc, file_dim;
        fi.read((char*)&file_nc , sizeof(int));
        fi.read((char*)&file_dim, sizeof(int));
        if (file_nc != n_clusters || file_dim != dim) {
            std::cerr << "centroid dim mismatch\n";  return false;
        }
        centroids = new float[n_clusters * dim];
        fi.read((char*)centroids, n_clusters * dim * sizeof(float));
        return true;
    }

    bool load_ivf_lists(const char* path) {
        std::ifstream fi(path, std::ios::binary);
        if (!fi) { std::cerr << "open " << path << " failed\n"; return false; }

        list_sizes = new int[n_clusters];
        ivf_lists  = new int*[n_clusters];
        for (int i = 0; i < n_clusters; ++i) {
            fi.read((char*)&list_sizes[i], sizeof(int));
            if (list_sizes[i] > 0) {
                ivf_lists[i] = new int[list_sizes[i]];
                fi.read((char*)ivf_lists[i], list_sizes[i] * sizeof(int));
            } else ivf_lists[i] = nullptr;
        }
        return true;
    }

    /******************** 基础工具函数 ********************/
    inline float inner_product(const float* a, const float* b, int sz) const {
        float s = 0.f;
        for (int i = 0; i < sz; ++i) s += a[i] * b[i];
        return s;
    }

    /********************************************************
     *  多线程计算 query 与所有簇中心的相似度（内积越大越近） *
     ********************************************************/
   static void distance_worker(const IVFIndex* self,
                            const float*     query,
                            float*           dist_out, // 改名为 sim_out 更合适
                            int*             idx_out,
                            int              beg,
                            int              end)
{
    for (int i = beg; i < end; ++i) {
        // 直接计算内积相似度，越大越相似
        dist_out[i] = self->inner_product(query,
                                         &self->centroids[i * self->dim],
                                         self->dim);
        idx_out[i] = i;
    }
}

    /*  选 nprobe 个“最近簇”。selected_clusters 长度 ≥ nprobe。
        策略：取内积最大的 nprobe 个簇。  */
    void select_clusters(const float* query,
                         int          nprobe,
                         int*         selected_clusters) const
    {
        /* ---------- 1. 计算 query 与所有簇中心的相似度 ---------- */
        float* distances = new float[n_clusters];
        int*   indices   = new int  [n_clusters];

        int thread_num = std::min(NUM_THREADS, n_clusters);
        std::vector<std::thread> ths;
        int chunk = n_clusters / thread_num;
        int rem   = n_clusters % thread_num;
        int st = 0;
        for (int t = 0; t < thread_num; ++t) {
            int ed = st + chunk + (t < rem ? 1 : 0);
            ths.emplace_back(distance_worker,
                             this, query, distances, indices, st, ed);
            st = ed;
        }
        for (auto& th : ths) th.join();

        /* ---------- 2. 用最小堆保留 nprobe 个最大内积 ---------- */
       // 使用最小堆保留 nprobe 个最大相似度
    using Pair = std::pair<float, int>;
    auto cmp = [](const Pair& a, const Pair& b) { return a.first > b.first; }; // 最小堆
    std::priority_queue<Pair, std::vector<Pair>, decltype(cmp)> pq(cmp);

    for (int i = 0; i < n_clusters; ++i) {
        float sim = distances[i]; // 这里是相似度，越大越好
        if ((int)pq.size() < nprobe) {
            pq.emplace(sim, i);
        } else if (sim > pq.top().first) { // 如果当前相似度更大
            pq.pop();
            pq.emplace(sim, i);
        }
    }
    
    // 提取结果
    int i=0;
    while (!pq.empty()) {
        selected_clusters[i]=pq.top().second;
        pq.pop();
        i=i+1;
    }

        delete[] distances;
        delete[] indices;
    }

    /******************** 子线程搜索单个簇 ********************/
    void search_in_cluster(float*  base,
                           float*  query,
                           size_t  vecdim,
                           size_t  k,
                           int     cluster_id,
                           std::priority_queue<std::pair<float,uint32_t>>& local_q)
    {
        int list_size = list_sizes[cluster_id];
        if (list_size == 0) return;

        for (int i = 0; i < list_size; ++i) {
            int   idx = ivf_lists[cluster_id][i];
            float sim = inner_product(query, &base[idx * vecdim], (int)vecdim);
            float dist = 1.f - sim;                   // 距离 = 1-相似度
            if (local_q.size() < k)          local_q.emplace(dist, idx);
            else if (dist < local_q.top().first) { local_q.pop(); local_q.emplace(dist, idx); }
        }
    }

public:
    /******************** 对外搜索接口 ********************/
    std::priority_queue<std::pair<float,uint32_t>>
    search(float*  base,
           float*  query,
           size_t  base_num,
           size_t  vecdim,
           size_t  k,
           int     nprobe = 8)
    {
        if (!index_loaded && !load_index())
            return {};             // 加载失败直接返回空队列

        assert(vecdim == dim);

        /* ---------- step1 选簇 ---------- */
        nprobe = std::min(nprobe, n_clusters);
        std::vector<int> sel(nprobe);
        select_clusters(query, nprobe, sel.data());

        /* ---------- step2 启动 nprobe 线程并行扫倒排 ---------- */
        std::vector<std::thread> ths;
        std::vector<std::priority_queue<std::pair<float,uint32_t>>> locals(nprobe);

        for (int p = 0; p < nprobe; ++p) {
            int cid = sel[p];
            if (cid < 0) continue;
            ths.emplace_back(&IVFIndex::search_in_cluster, this,
                             base, query, vecdim, k, cid, std::ref(locals[p]));
        }
        for (auto& t : ths) t.join();

        /* ---------- step3 合并局部结果 ---------- */
        std::priority_queue<std::pair<float,uint32_t>> final_q;
        for (auto& q : locals)
            while (!q.empty()){
                if (final_q.size() < k) final_q.push(q.top());
                else if (q.top().first < final_q.top().first) {
                    final_q.pop();  final_q.push(q.top());
                }
                q.pop();
            }
        return final_q;
    }
};

/******************** 全局对象 & C 风格封装 ********************/
static IVFIndex g_ivf_index;

inline bool preload_index(const char* dir = "files")         { return g_ivf_index.load_index(dir); }

inline std::priority_queue<std::pair<float,uint32_t>>
ivf_search(float* base, float* query,
           size_t base_num, size_t vecdim,
           size_t k,      int    nprobe = 8)
{
    return g_ivf_index.search(base, query, base_num, vecdim, k, nprobe);
}

#endif  // IVF_SEARCH_H