#ifndef IVF_SEARCH_H
#define IVF_SEARCH_H

#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <vector>
#include <atomic>
#include <pthread.h>
#include <functional>
#include <thread>
#include <numeric>

#define N_CLUSTERS 1024
#define DIM        96
#define MAX_THREAD 6            // 可按机器核数调整
#define TH_MULTI_THRESHOLD 4    // nprobe > 4 才启多线程，否则单线程


//pthread线程池
class ThreadPool {
public:
    using Task = std::function<void()>;

    explicit ThreadPool(size_t n_threads = 0) : stop(false) {
        if (n_threads == 0)
            n_threads = std::min<size_t>(MAX_THREAD,
                                          std::thread::hardware_concurrency());

        workers.resize(n_threads);
        pthread_mutex_init(&q_mtx, nullptr);
        pthread_cond_init (&q_cv,  nullptr);

        for (size_t i = 0; i < n_threads; ++i)
            pthread_create(&workers[i], nullptr, worker_entry, this);
    }

    ~ThreadPool() {
        // 通知线程退出
        pthread_mutex_lock(&q_mtx);
        stop = true;
        pthread_cond_broadcast(&q_cv);
        pthread_mutex_unlock(&q_mtx);

        for (auto &th : workers) pthread_join(th, nullptr);

        pthread_mutex_destroy(&q_mtx);
        pthread_cond_destroy (&q_cv);
    }

    //处理数量
    size_t workers_count() const noexcept { return workers.size(); }

    // 提交任务
    void enqueue(Task&& task) {
        pthread_mutex_lock(&q_mtx);
        tasks.emplace(std::move(task));
        pthread_cond_signal(&q_cv);
        pthread_mutex_unlock(&q_mtx);
    }

    // 等待任务全部完成（简易 barrier）
    void wait_all() {
        pthread_mutex_lock(&q_mtx);
        while (!tasks.empty() || working_cnt > 0)
            pthread_cond_wait(&q_cv, &q_mtx);
        pthread_mutex_unlock(&q_mtx);
    }

private:
    static void* worker_entry(void* arg) {
        auto *pool = static_cast<ThreadPool*>(arg);
        pool->worker_loop();
        return nullptr;
    }

    void worker_loop() {
        for (;;) {
            pthread_mutex_lock(&q_mtx);
            while (tasks.empty() && !stop)
                pthread_cond_wait(&q_cv, &q_mtx);

            if (stop && tasks.empty()) {
                pthread_mutex_unlock(&q_mtx);
                break;
            }

            Task task = std::move(tasks.front());
            tasks.pop();
            ++working_cnt;
            pthread_mutex_unlock(&q_mtx);

            // ---- 执行任务 ----
            task();

            // ---- 任务结束 ----
            pthread_mutex_lock(&q_mtx);
            --working_cnt;
            if (tasks.empty() && working_cnt == 0)
                pthread_cond_broadcast(&q_cv);     // 唤醒 wait_all()
            pthread_mutex_unlock(&q_mtx);
        }
    }
private:
    std::vector<pthread_t> workers;
    std::queue<Task> tasks;
    pthread_mutex_t q_mtx;
    pthread_cond_t  q_cv;
    size_t working_cnt = 0;
    bool stop;
};

class IVFIndex {
private:
    float* centroids;           // 簇中心 [N_CLUSTERS * DIM]
    int** ivf_lists;           // 倒排索引 [N_CLUSTERS][list_size]
    int* list_sizes;           // 每个簇的大小 [N_CLUSTERS]
    int n_clusters;
    int dim;
    bool index_loaded;
      /* ---- 新增：常驻线程池 ---- */
    ThreadPool thread_pool;

public:
    IVFIndex() : centroids(nullptr), ivf_lists(nullptr), list_sizes(nullptr),
                 n_clusters(N_CLUSTERS), dim(DIM), index_loaded(false),
                 thread_pool() { }          // 默认启动线程池

    ~IVFIndex() { free_memory(); }
    
    void free_memory() {
        if (centroids) {
            delete[] centroids;
            centroids = nullptr;
        }
        if (list_sizes) {
            delete[] list_sizes;
            list_sizes = nullptr;
        }
        if (ivf_lists) {
            for (int i = 0; i < n_clusters; ++i) {
                if (ivf_lists[i]) {
                    delete[] ivf_lists[i];
                }
            }
            delete[] ivf_lists;
            ivf_lists = nullptr;
        }
        index_loaded = false;
    }
    
    bool load_index(const char* index_dir = "files") {
        if (index_loaded) {
            return true;
        }
        
        // 构建文件路径
        char centroids_path[256];
        char ivf_path[256];
        snprintf(centroids_path, sizeof(centroids_path), "%s/centroids.bin", index_dir);
        snprintf(ivf_path, sizeof(ivf_path), "%s/ivf_lists.bin", index_dir);
        
        // 加载簇中心
        if (!load_centroids(centroids_path)) {
            return false;
        }
        
        // 加载倒排索引
        if (!load_ivf_lists(ivf_path)) {
            return false;
        }
        
        index_loaded = true;
        return true;
    }
    
private:
    bool load_centroids(const char* path) {
        std::ifstream file(path, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Failed to open centroids file: " << path << std::endl;
            return false;
        }
        
        int file_n_clusters, file_dim;
        file.read(reinterpret_cast<char*>(&file_n_clusters), sizeof(int));
        file.read(reinterpret_cast<char*>(&file_dim), sizeof(int));
        
        if (file_n_clusters != n_clusters || file_dim != dim) {
            std::cerr << "Dimension mismatch in centroids file" << std::endl;
            file.close();
            return false;
        }
        
        centroids = new float[n_clusters * dim];
        file.read(reinterpret_cast<char*>(centroids), n_clusters * dim * sizeof(float));
        file.close();
        
        return true;
    }
    
    bool load_ivf_lists(const char* path) {
        std::ifstream file(path, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Failed to open IVF lists file: " << path << std::endl;
            return false;
        }
        
        list_sizes = new int[n_clusters];
        ivf_lists = new int*[n_clusters];
        
        for (int i = 0; i < n_clusters; ++i) {
            file.read(reinterpret_cast<char*>(&list_sizes[i]), sizeof(int));
            
            if (list_sizes[i] > 0) {
                ivf_lists[i] = new int[list_sizes[i]];
                file.read(reinterpret_cast<char*>(ivf_lists[i]), list_sizes[i] * sizeof(int));
            } else {
                ivf_lists[i] = nullptr;
            }
        }
        
        file.close();
        return true;
    }
    
    // 内积计算 - 内联函数便于并行化
    inline float inner_product(const float* a, const float* b, int size) const {
        float result = 0.0f;
        // 可以使用SIMD指令优化
        for (int i = 0; i < size; ++i) {
            result += a[i] * b[i];
        }
        return result;
    }
    
    // 选择最近的nprobe个簇 
    void select_clusters(const float* query, int nprobe, int* selected_clusters) const {
        // 计算到所有簇中心的距离
        float* distances = new float[n_clusters];
        int* indices = new int[n_clusters];

        // 计算每个簇中心与查询点的内积
        for (int i = 0; i < n_clusters; ++i) {
            distances[i] = inner_product(query, &centroids[i * dim], dim);
            indices[i] = i;
        }

        //是否可修改
        // 部分排序选择top nprobe个簇
        for (int i = 0; i < nprobe; ++i) {
            int max_idx = i;
            for (int j = i + 1; j < n_clusters; ++j) {
                if (distances[j] > distances[max_idx]) {
                    max_idx = j;
                }
            }
            if (max_idx != i) {
                // 交换距离和索引
                float temp_dist = distances[i];
                distances[i] = distances[max_idx];
                distances[max_idx] = temp_dist;

                int temp_idx = indices[i];
                indices[i] = indices[max_idx];
                indices[max_idx] = temp_idx;
            }
        }

        // 复制选中的簇索引
        for (int i = 0; i < nprobe; ++i) {
            selected_clusters[i] = indices[i];
        }

        delete[] distances;
        delete[] indices;
    }
    // 并行版：利用 thread_pool 抢任务，把 centroids 划块计算
void select_clusters_parallel(const float* query,
                              int nprobe,
                              int* selected_clusters,
                              ThreadPool& pool) const
{
    const size_t tnum  = pool.workers_count();
    const size_t chunk = 128;                    // ★ 每次抢 128 个簇，可自行调大/调小
    std::vector<float> distances(n_clusters);    // 全局距离缓冲

    std::atomic<int> cursor(0);
    for (size_t tid = 0; tid < tnum; ++tid) {
        pool.enqueue([&, tid] {
            for (;;) {
                int start = cursor.fetch_add(chunk, std::memory_order_relaxed);
                if (start >= n_clusters) break;
                int end   = std::min(start + (int)chunk, n_clusters);

                // 计算 [start, end) 这一块簇的内积
                for (int idx = start; idx < end; ++idx)
                    distances[idx] = inner_product(query,
                                                   &centroids[idx * dim], dim);
            }
        });
    }
    pool.wait_all();       // 所有块都完成

    // ------- 挑 top-nprobe -------
    std::vector<int> indices(n_clusters);
    std::iota(indices.begin(), indices.end(), 0);

    std::partial_sort(indices.begin(), indices.begin() + nprobe, indices.end(),
                      [&](int a, int b) { return distances[a] > distances[b]; });

    std::memcpy(selected_clusters, indices.data(), nprobe * sizeof(int));
}
public:
    // 主搜索函数
    //并行 search() 实现
    std::priority_queue<std::pair<float,uint32_t>>
    search(float* base, float* query, size_t base_number, size_t vecdim,
           size_t k, int nprobe = 8)
    {
       
        /* --------- 多线程路径 --------- */
        if (!index_loaded && !load_index()) {
            std::cerr << "Failed to load index\n";
            return {};
        }
        assert(vecdim == dim);

        // 1) nprobe 个簇
        std::vector<int> sel_clusters(nprobe);
        select_clusters_parallel(query, nprobe, sel_clusters.data(), thread_pool);

        // 2) 每个线程一个本地 top-k 最小堆
        size_t thread_num = thread_pool_size();
        std::vector< std::priority_queue<std::pair<float,uint32_t>> >
                local_heaps(thread_num);

        // 3) 全局原子游标(动态调度任务)
        std::atomic<int> cursor(0);

        // 4) 给线程池提交 worker
        for (size_t tid = 0; tid < thread_num; ++tid) {
            thread_pool.enqueue([&, tid]{
                auto &heap = local_heaps[tid];

                for (;;) {
                    int idx = cursor.fetch_add(1, std::memory_order_relaxed);
                    if (idx >= nprobe) break;          // 没活了
                    int cid  = sel_clusters[idx];
                    int lsz  = list_sizes[cid];
                    if (lsz == 0) continue;

                    const int* ids = ivf_lists[cid];
                    for (int j = 0; j < lsz; ++j) {
                        int data_idx = ids[j];
                        float dist = 1.0f -
                                     inner_product(query, &base[data_idx * vecdim], vecdim);

                        if (heap.size() < k)
                            heap.push({dist, (uint32_t)data_idx});
                        else if (dist < heap.top().first) {
                            heap.pop();
                            heap.push({dist, (uint32_t)data_idx});
                        }
                    }
                }
            });
        }

        // 5) 等全部 worker 结束
        thread_pool.wait_all();

        // 6) 合并所有局部堆 -> 全局堆，再裁成 k 个
        std::priority_queue<std::pair<float,uint32_t>> global_heap;
        for (auto &hp : local_heaps) {
            while (!hp.empty()) {
                auto elem = hp.top(); hp.pop();
                if (global_heap.size() < k)
                    global_heap.push(elem);
                else if (elem.first < global_heap.top().first) {
                    global_heap.pop();
                    global_heap.push(elem);
                }
            }
        }
        return global_heap;
    }
private:
//保留单例，供小nprobe使用
 std::priority_queue<std::pair<float,uint32_t>>
    search_single_thread(float* base, float* query, size_t base_number,
                         size_t vecdim, size_t k, int nprobe)
    {
        if (!index_loaded && !load_index()) {
            std::cerr << "Failed to load index\n";
            return {};
        }
        assert(vecdim == dim);

        std::vector<int> sel_clusters(nprobe);
        select_clusters(query, nprobe, sel_clusters.data());
        std::priority_queue<std::pair<float,uint32_t>> heap;

        for (int p = 0; p < nprobe; ++p) {
            int cid  = sel_clusters[p];
            int lsz  = list_sizes[cid];
            if (lsz == 0) continue;

            const int* ids = ivf_lists[cid];
            for (int j = 0; j < lsz; ++j) {
                int data_idx = ids[j];
                float dist = 1.0f -
                             inner_product(query, &base[data_idx * vecdim], vecdim);

                if (heap.size() < k)
                    heap.push({dist, (uint32_t)data_idx});
                else if (dist < heap.top().first) {
                    heap.pop(); heap.push({dist, (uint32_t)data_idx});
                }
            }
        }
        return heap;
    }
    size_t thread_pool_size() const { return std::max<size_t>(1, thread_pool.workers_count()); }

};

// 全局索引实例
static IVFIndex g_ivf_index;

// 主搜索接口函数
inline std::priority_queue<std::pair<float, uint32_t>> ivf_search(
    float* base, float* query, size_t base_number, size_t vecdim, size_t k, int nprobe = 8) {
    return g_ivf_index.search(base, query, base_number, vecdim, k, nprobe);
}

// 预加载索引函数
inline bool preload_index(const char* index_dir = "files") {
    return g_ivf_index.load_index(index_dir);
}

#endif // IVF_SEARCH_H