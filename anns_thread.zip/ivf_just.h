#ifndef IVF_SEARCH_H
#define IVF_SEARCH_H

#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cassert>

#define N_CLUSTERS 1024
#define DIM 96

class IVFIndex {
private:
    float* centroids;           // 簇中心 [N_CLUSTERS * DIM]
    int** ivf_lists;           // 倒排索引 [N_CLUSTERS][list_size]
    int* list_sizes;           // 每个簇的大小 [N_CLUSTERS]
    int n_clusters;
    int dim;
    bool index_loaded;

public:
    IVFIndex() : centroids(nullptr), ivf_lists(nullptr), list_sizes(nullptr), 
                 n_clusters(N_CLUSTERS), dim(DIM), index_loaded(false) {}
    
    ~IVFIndex() {
        free_memory();
    }
    
    void free_memory() {
        if (centroids) {
            delete[] centroids;
            centroids = nullptr;
        }
        if (list_sizes) {
            delete[] list_sizes;
            list_sizes = nullptr;
        }
        if (ivf_lists) {
            for (int i = 0; i < n_clusters; ++i) {
                if (ivf_lists[i]) {
                    delete[] ivf_lists[i];
                }
            }
            delete[] ivf_lists;
            ivf_lists = nullptr;
        }
        index_loaded = false;
    }
    
    bool load_index(const char* index_dir = "files") {
        if (index_loaded) {
            return true;
        }
        
        // 构建文件路径
        char centroids_path[256];
        char ivf_path[256];
        snprintf(centroids_path, sizeof(centroids_path), "%s/centroids.bin", index_dir);
        snprintf(ivf_path, sizeof(ivf_path), "%s/ivf_lists.bin", index_dir);
        
        // 加载簇中心
        if (!load_centroids(centroids_path)) {
            return false;
        }
        
        // 加载倒排索引
        if (!load_ivf_lists(ivf_path)) {
            return false;
        }
        
        index_loaded = true;
        return true;
    }
    
private:
    bool load_centroids(const char* path) {
        std::ifstream file(path, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Failed to open centroids file: " << path << std::endl;
            return false;
        }
        
        int file_n_clusters, file_dim;
        file.read(reinterpret_cast<char*>(&file_n_clusters), sizeof(int));
        file.read(reinterpret_cast<char*>(&file_dim), sizeof(int));
        
        if (file_n_clusters != n_clusters || file_dim != dim) {
            std::cerr << "Dimension mismatch in centroids file" << std::endl;
            file.close();
            return false;
        }
        
        centroids = new float[n_clusters * dim];
        file.read(reinterpret_cast<char*>(centroids), n_clusters * dim * sizeof(float));
        file.close();
        
        return true;
    }
    
    bool load_ivf_lists(const char* path) {
        std::ifstream file(path, std::ios::binary);
        if (!file.is_open()) {
            std::cerr << "Failed to open IVF lists file: " << path << std::endl;
            return false;
        }
        
        list_sizes = new int[n_clusters];
        ivf_lists = new int*[n_clusters];
        
        for (int i = 0; i < n_clusters; ++i) {
            file.read(reinterpret_cast<char*>(&list_sizes[i]), sizeof(int));
            
            if (list_sizes[i] > 0) {
                ivf_lists[i] = new int[list_sizes[i]];
                file.read(reinterpret_cast<char*>(ivf_lists[i]), list_sizes[i] * sizeof(int));
            } else {
                ivf_lists[i] = nullptr;
            }
        }
        
        file.close();
        return true;
    }
    
    // 内积计算 - 内联函数便于并行化
    inline float inner_product(const float* a, const float* b, int size) const {
        float result = 0.0f;
        // 可以使用SIMD指令优化
        for (int i = 0; i < size; ++i) {
            result += a[i] * b[i];
        }
        return result;
    }
    
    // 选择最近的nprobe个簇 
    void select_clusters(const float* query, int nprobe, int* selected_clusters) const {
        // 计算到所有簇中心的距离
        float* distances = new float[n_clusters];
        int* indices = new int[n_clusters];

        // 计算每个簇中心与查询点的内积
        for (int i = 0; i < n_clusters; ++i) {
            distances[i] = 1-inner_product(query, &centroids[i * dim], dim);
            indices[i] = i;
        }

       std::priority_queue<std::pair<float, int>> pq; // 最大堆，存储（距离，索引）

        for (int j = 0; j < n_clusters; ++j) {
            float dist = distances[j];
            if (pq.size() < nprobe) {
                pq.emplace(dist, j);
            } else if (dist < pq.top().first) {
                pq.pop();
                pq.emplace(dist, j);
            }
        }

        // 按距离从大到小（堆顶到堆底）的顺序填充结果数组
        for (int i = 0; i < nprobe; ++i) {
            selected_clusters[i] = pq.top().second;
            pq.pop();
        }


        delete[] distances;
        delete[] indices;
    }
public:
    // 主搜索函数
   // 主搜索函数
    std::priority_queue<std::pair<float, uint32_t>> search(
        float* base, float* query, size_t base_number, size_t vecdim, 
        size_t k, int nprobe = 8) {

        if (!index_loaded) {
            if (!load_index()) {
                std::cerr << "Failed to load index" << std::endl;
                return std::priority_queue<std::pair<float, uint32_t>>();
            }
        }

        assert(vecdim == dim);

        // 选择最近的nprobe个簇
        int* selected_clusters = new int[nprobe];
        select_clusters(query, nprobe, selected_clusters);

        // 在选中的簇中搜索
        std::priority_queue<std::pair<float, uint32_t>> result_queue;

        for (int p = 0; p < nprobe; ++p) {
            int cluster_id = selected_clusters[p];
            int list_size = list_sizes[cluster_id];

            if (list_size == 0) continue;

            // 在当前簇中搜索
            for (int i = 0; i < list_size; ++i) {
                int data_idx = ivf_lists[cluster_id][i];

                // 计算内积
                float dot_product = inner_product(query, &base[data_idx * vecdim], vecdim);
                float distance = 1.0f - dot_product;  // 转换为距离

                // 更新结果队列
                if (result_queue.size() < k) {
                    result_queue.push({distance, static_cast<uint32_t>(data_idx)});
                } else if (distance < result_queue.top().first) {
                    result_queue.pop();
                    result_queue.push({distance, static_cast<uint32_t>(data_idx)});
                }
            }
        }

        delete[] selected_clusters;
        return result_queue;
    }

};

// 全局索引实例
static IVFIndex g_ivf_index;

// 主搜索接口函数
inline std::priority_queue<std::pair<float, uint32_t>> ivf_search(
    float* base, float* query, size_t base_number, size_t vecdim, size_t k, int nprobe = 8) {
    return g_ivf_index.search(base, query, base_number, vecdim, k, nprobe);
}

// 预加载索引函数
inline bool preload_index(const char* index_dir = "files") {
    return g_ivf_index.load_index(index_dir);
}

#endif // IVF_SEARCH_H