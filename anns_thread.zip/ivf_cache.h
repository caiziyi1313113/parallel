#ifndef IVF_SEARCH_H
#define IVF_SEARCH_H

#include <iostream>
#include <fstream>
#include <queue>
#include <algorithm>
#include <cstring>
#include <cassert>
#include <vector>
#include <atomic>
#include <pthread.h>
#include <thread>
#include <numeric>
#include <functional>

#define N_CLUSTERS 1024
#define DIM        96
#define MAX_THREAD 2

/* ------------------------- 线程池 ------------------------- */
class ThreadPool {
public:
    using Task = std::function<void()>;
    explicit ThreadPool(size_t n_threads = 0) : stop(false) {
        if (n_threads == 0) n_threads = MAX_THREAD;
        workers.resize(n_threads);
        pthread_mutex_init(&q_mtx, nullptr);
        pthread_cond_init (&q_cv , nullptr);
        for (size_t i = 0; i < n_threads; ++i)
            pthread_create(&workers[i], nullptr, worker_entry, this);
    }
    ~ThreadPool() {
        pthread_mutex_lock(&q_mtx);  stop = true;
        pthread_cond_broadcast(&q_cv);  pthread_mutex_unlock(&q_mtx);
        for (auto &th: workers) pthread_join(th,nullptr);
        pthread_mutex_destroy(&q_mtx);  pthread_cond_destroy(&q_cv);
    }
    size_t workers_count() const noexcept { return workers.size(); }
    void enqueue(Task&& t){
        pthread_mutex_lock(&q_mtx);
        tasks.emplace(std::move(t));
        pthread_cond_signal(&q_cv);
        pthread_mutex_unlock(&q_mtx);
    }
    void wait_all(){
        pthread_mutex_lock(&q_mtx);
        while(!tasks.empty() || working_cnt>0)
            pthread_cond_wait(&q_cv,&q_mtx);
        pthread_mutex_unlock(&q_mtx);
    }
private:
    static void* worker_entry(void* arg){
        static_cast<ThreadPool*>(arg)->worker_loop(); return nullptr;
    }
    void worker_loop(){
        for(;;){
            pthread_mutex_lock(&q_mtx);
            while(tasks.empty() && !stop) pthread_cond_wait(&q_cv,&q_mtx);
            if(stop && tasks.empty()){ pthread_mutex_unlock(&q_mtx); break; }
            Task task = std::move(tasks.front()); tasks.pop(); ++working_cnt;
            pthread_mutex_unlock(&q_mtx);

            task();   // run

            pthread_mutex_lock(&q_mtx);
            --working_cnt;
            if(tasks.empty() && working_cnt==0) pthread_cond_broadcast(&q_cv);
            pthread_mutex_unlock(&q_mtx);
        }
    }
    std::vector<pthread_t> workers;
    std::queue<Task> tasks;
    pthread_mutex_t q_mtx; pthread_cond_t q_cv;
    size_t working_cnt = 0; bool stop;
};

/* =============================== IVF Index =============================== */
class IVFIndex {
public:
    IVFIndex()
    //加载簇心，重排后的base，list_offset，每个簇的起始位置、簇的大小，reorder_map是什么
        : centroids_(nullptr), base_vecs_(nullptr),
          list_offset_(nullptr), list_size_(nullptr),
          reorder_map_(nullptr),                       /* ⚡ */
          n_clusters_(N_CLUSTERS), dim_(DIM), ntotal_(0),
          index_loaded_(false), thread_pool_() {}
    ~IVFIndex() { free_memory(); }

    bool load_index(const char* dir = "files") {
        if(index_loaded_) return true;
        if(!load_centroids(dir))      return false;
        if(!load_meta(dir))           return false;
        if(!load_reorder_map(dir))    return false;    /* ⚡ */
        if(!load_base_vectors(dir))   return false;
        index_loaded_ = true;
        return true;
    }

    /* --------------------------- 搜索主函数 --------------------------- */
    std::priority_queue<std::pair<float,uint32_t>>
    search(const float* query, size_t k, int nprobe = 8)
    {
        if(!index_loaded_ && !load_index()){
            std::cerr<<"index load failed\n"; return {};
        }

        /* 1. 选簇 */
        std::vector<int> sel(nprobe);
        select_clusters_parallel(query,nprobe,sel.data());

        /* 大簇优先 */
        std::sort(sel.begin(), sel.end(),
                  [&](int a,int b){return list_size_[a] > list_size_[b];});

        /* 2. 多线程遍历 */
        size_t tnum = thread_pool_.workers_count();
        std::vector< std::priority_queue<std::pair<float,uint32_t>> >
                local_heaps(tnum);

        std::atomic<int> cursor(0);
        for(size_t tid=0; tid<tnum; ++tid){
            thread_pool_.enqueue([&,tid]{
                auto &heap = local_heaps[tid];
                for(;;){
                    int idx = cursor.fetch_add(1,std::memory_order_relaxed);
                    if(idx >= nprobe) break;
                    int cid = sel[idx];//获取簇的索引
                    int sz  = list_size_[cid];//获取当前簇的向量数量
                    if(sz==0) continue;
                    //获取当前簇在重排base中的起始位置
                    const float* block = base_vecs_ + (size_t)list_offset_[cid]*dim_;
                    for(int j=0;j<sz;++j){
                        //连续访问base_vecs_，避免cache miss
                        const float* vec = block + (size_t)j*dim_;
                        float ip = inner_product(query, vec, dim_);
                        float dist = 1.0f - ip;               // cosine 距离
                        uint32_t inner_id = list_offset_[cid] + j;      // 内部 id
                        uint32_t orig_id  = reorder_map_[inner_id];     // ⚡ 映射

                        if(heap.size()<k) heap.push({dist,orig_id});
                        else if(dist < heap.top().first){
                            heap.pop(); heap.push({dist,orig_id});
                        }
                    }
                }
            });
        }
        thread_pool_.wait_all();

        /* 3. merge */
        std::priority_queue<std::pair<float,uint32_t>> global_heap;
        for(auto &hp: local_heaps){
            while(!hp.empty()){
                auto e=hp.top(); hp.pop();
                if(global_heap.size()<k)      global_heap.push(e);
                else if(e.first < global_heap.top().first){
                    global_heap.pop(); global_heap.push(e);
                }
            }
        }
        return global_heap;
    }

private:
    /* ---------- 加载 ---------- */
    //加载聚类中心
    bool load_centroids(const char* dir){
        std::string path = std::string(dir) + "/centroids.bin";
        std::ifstream fin(path, std::ios::binary);
        if(!fin){ std::cerr<<"open "<<path<<" fail\n"; return false; }

        uint32_t n,d;  fin.read((char*)&n,4); fin.read((char*)&d,4);
        if(n!=n_clusters_ || d!=dim_){
            std::cerr<<"centroid shape mismatch\n"; return false;
        }
        centroids_ = new float[(size_t)n_clusters_*dim_];
        fin.read((char*)centroids_, (size_t)n_clusters_*dim_*sizeof(float));
        fin.close();
        return true;
    }
    //加载 IVF 索引的元数据，具体是每个聚类的偏移量和长度。
    bool load_meta(const char* dir){
        std::string path = std::string(dir)+"/ivf_offset_len.bin";
        std::ifstream fin(path, std::ios::binary);
        if(!fin){ std::cerr<<"open "<<path<<" fail\n"; return false; }

        const size_t elems = (size_t)n_clusters_ * 2;           // [offset, len]
        std::vector<uint32_t> buf(elems);
        fin.read(reinterpret_cast<char*>(buf.data()), elems * sizeof(uint32_t));
        if(!fin){ std::cerr<<"read meta fail\n"; return false; }
        fin.close();

        list_offset_ = new uint32_t[n_clusters_];
        list_size_   = new uint32_t[n_clusters_];
        ntotal_ = 0;
        for(int i=0;i<n_clusters_; ++i){
            list_offset_[i] = buf[2*i];
            list_size_[i]   = buf[2*i+1];
            ntotal_        += list_size_[i];
        }
        return true;
    }

    /* ⚡ 读取重排到原始的映射 */
    bool load_reorder_map(const char* dir){
        std::string path = std::string(dir)+"/reorder_indices.bin";
        std::ifstream fin(path, std::ios::binary);
        if(!fin){
            std::cerr<<"open "<<path<<" fail (recall will be wrong)\n";
            return false;
        }
        reorder_map_ = new uint32_t[ntotal_];
        fin.read(reinterpret_cast<char*>(reorder_map_), ntotal_*sizeof(uint32_t));
        if(!fin){ std::cerr<<"read reorder map fail\n"; return false; }
        fin.close();  return true;
    }

    /* base 向量一次性读入内存 */
    bool load_base_vectors(const char* dir){
        std::string path = std::string(dir)+"/clustered_base.bin";
        std::ifstream fin(path, std::ios::binary);
        if(!fin){ std::cerr<<"open "<<path<<" fail\n"; return false; }

        uint32_t n,d;  fin.read((char*)&n,4); fin.read((char*)&d,4);
        if(d!=dim_ || (ntotal_!=0 && n!=ntotal_)){
            std::cerr<<"base header mismatch: "<<n<<" vs "<<ntotal_<<"\n";
            return false;
        }

        size_t total_floats = (size_t)n * dim_;
        base_vecs_ = new float[total_floats];
        fin.read(reinterpret_cast<char*>(base_vecs_),
                 total_floats * sizeof(float));
        if(!fin){ std::cerr<<"read base vecs fail\n"; return false; }
        fin.close();
        return true;
    }

    /* ---------- 计算 & 选簇 ---------- */
    inline float inner_product(const float* a,const float* b,int n) const{
        float s=0.f; for(int i=0;i<n;++i) s+=a[i]*b[i]; return s;
    }

    void select_clusters_parallel(const float* q,int nprobe,int* out) {
        const size_t tnum = thread_pool_.workers_count();
        const size_t chunk=128;
        std::vector<float> dists(n_clusters_);
        std::atomic<int> cursor(0);

        for(size_t t=0;t<tnum;++t){
            thread_pool_.enqueue([&,t]{
                for(;;){
                    int st = cursor.fetch_add(chunk,std::memory_order_relaxed);
                    if(st>=n_clusters_) break;
                    int ed = std::min(st+(int)chunk, n_clusters_);
                    for(int i=st;i<ed;++i)
                        dists[i]=inner_product(q, centroids_+ (size_t)i*dim_, dim_);
                }
            });
        }
        thread_pool_.wait_all();

        std::vector<int> idx(n_clusters_); std::iota(idx.begin(),idx.end(),0);
        std::partial_sort(idx.begin(), idx.begin()+nprobe, idx.end(),
                          [&](int a,int b){return dists[a]>dists[b];});
        std::memcpy(out, idx.data(), nprobe*sizeof(int));
    }

    /* ---------- 内存释放 ---------- */
    void free_memory(){
        if(centroids_){ delete[] centroids_; centroids_=nullptr;}
        if(list_offset_){ delete[] list_offset_; list_offset_=nullptr;}
        if(list_size_){ delete[] list_size_; list_size_=nullptr;}
        if(base_vecs_){ delete[] base_vecs_; base_vecs_=nullptr;}
        if(reorder_map_){ delete[] reorder_map_; reorder_map_=nullptr;}  /* ⚡ */
        index_loaded_=false;
    }

/* ----------------------- data member ----------------------- */
    //全是一维数据
    float*      centroids_;
    float*      base_vecs_;          // 整库已读入内存
    uint32_t*   list_offset_;
    uint32_t*   list_size_;
    uint32_t*   reorder_map_;        // ⚡ new
    const int   n_clusters_, dim_;
    uint32_t    ntotal_;
    bool        index_loaded_;
    ThreadPool  thread_pool_;
};

/* ======== 对外接口 ======== */
static IVFIndex g_ivf;

inline bool preload_index(const char* dir="files"){ return g_ivf.load_index(dir); }

inline std::priority_queue<std::pair<float,uint32_t>>
ivf_search(const float* query,size_t topk,int nprobe=8){
    return g_ivf.search(query, topk, nprobe);
}

#endif /* IVF_SEARCH_H */