/**************************************************************
 *  ivf_pq_search.h  –  多线程版本（pthread + 静态线程池 + 任务池）
 *************************************************************/
#ifndef IVF_PQ_SEARCH_H
#define IVF_PQ_SEARCH_H

/*------------------------------------------------------------
 *  依赖
 *-----------------------------------------------------------*/
#include <algorithm>
#include <atomic>
#include <cassert>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <functional>
#include <iostream>
#include <mutex>
#include <numeric>
#include <pthread.h>
#include <queue>
#include <sched.h>
#include <vector>
#include <stddef.h>
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    #include <arm_neon.h>
#endif
/**************************************************************
 *                    0. 线程池 / 任务池
 *************************************************************/
#ifndef THREAD_NUM
#define THREAD_NUM 4          /* ⼿动修改线程数 */
#endif
#ifndef TASK_CAP
#define TASK_CAP   (1 << 14)  /*  16K 预分配 Task 节点 */
#endif

struct TaskNode {
    std::function<void()> job;
    TaskNode*             next;
};

/*---------------- 任务节点池链表 ----------------*/
class TaskPool {
public:
    explicit TaskPool(size_t cap = TASK_CAP) : cap_(cap) {
        nodes_ = (TaskNode*)std::malloc(sizeof(TaskNode) * cap_);
        for (size_t i = 0; i < cap_ - 1; ++i) nodes_[i].next = &nodes_[i + 1];
        nodes_[cap_ - 1].next = nullptr;
        free_head_ = nodes_;
        pthread_mutex_init(&mtx_, nullptr);
    }
    ~TaskPool() {
        pthread_mutex_destroy(&mtx_);
        std::free(nodes_);
    }
    //获取一个空闲的任务节点
    TaskNode* acquire() {
        //任务池是共享资源，需要互斥锁保护
        //获得互斥锁才可以对任务池进行操作
        pthread_mutex_lock(&mtx_);
        TaskNode* n = free_head_;
        if (n) free_head_ = n->next;
        pthread_mutex_unlock(&mtx_);
        return n;
    }
    //释放一个任务节点并将其放回空闲链表
    void release(TaskNode* n) {
        pthread_mutex_lock(&mtx_);
        n->next  = free_head_;
        free_head_ = n;
        pthread_mutex_unlock(&mtx_);
    }

private:
    size_t      cap_;
    TaskNode*   nodes_;
    TaskNode*   free_head_;
    pthread_mutex_t mtx_;
};

/*---------------- 静态线程池 ----------------*/
class ThreadPool {
public:
    ThreadPool(size_t tn = THREAD_NUM) : stop_(false), task_pool_(TASK_CAP) {
        pthread_mutex_init(&q_mtx_, nullptr);
        pthread_cond_init(&q_cv_,  nullptr);
        threads_.resize(tn);
        for (size_t i = 0; i < tn; ++i)
            pthread_create(&threads_[i], nullptr, worker, this);
    }
    ~ThreadPool() {
        /* 通知全部线程退出 */
        pthread_mutex_lock(&q_mtx_);
        stop_ = true;
        pthread_cond_broadcast(&q_cv_);
        pthread_mutex_unlock(&q_mtx_);
        for (auto& t : threads_) pthread_join(t, nullptr);
        pthread_mutex_destroy(&q_mtx_);
        pthread_cond_destroy(&q_cv_);
    }

    /* 投递任务（队列满 / 无节点时降级为同步执⾏） */
    void enqueue(const std::function<void()>& job) {
        TaskNode* n = task_pool_.acquire();
        if (!n) { job(); return; }           /* 降级同步 */

        n->job  = job;
        n->next = nullptr;

        pthread_mutex_lock(&q_mtx_);
        if (!q_tail_) q_head_ = q_tail_ = n;
        else { q_tail_->next = n; q_tail_ = n; }
        pthread_cond_signal(&q_cv_);
        pthread_mutex_unlock(&q_mtx_);
    }

private:
    static void* worker(void* arg) {
        auto* pool = (ThreadPool*)arg;
        while (true) {
            pthread_mutex_lock(&pool->q_mtx_);
            while (!pool->stop_ && !pool->q_head_)
                pthread_cond_wait(&pool->q_cv_, &pool->q_mtx_);

            if (pool->stop_) {
                pthread_mutex_unlock(&pool->q_mtx_);
                break;
            }
            TaskNode* n = pool->q_head_;
            pool->q_head_ = n->next;
            if (!pool->q_head_) pool->q_tail_ = nullptr;
            pthread_mutex_unlock(&pool->q_mtx_);

            n->job();                   /* 执行任务 */
            pool->task_pool_.release(n);
        }
        return nullptr;
    }

    /* data */
    std::vector<pthread_t> threads_;
    bool        stop_;
    TaskPool    task_pool_;

    TaskNode*   q_head_ = nullptr;
    TaskNode*   q_tail_ = nullptr;
    pthread_mutex_t q_mtx_;
    pthread_cond_t  q_cv_;
};

/* 获取全局线程池（懒初始化, 线程安全 by C++11） */
static ThreadPool& getPool() {
    static ThreadPool pool(THREAD_NUM);
    return pool;
}

/**************************************************************
 *                    1. IVF-PQ 参数 & 工具
 *************************************************************/
#define N_LIST  1024
#define DIM     96
#define M       16
#define K_PQ    16
#define DIM_PER_SUBSPACE (DIM / M)

/************  对齐内存  ************/
static inline float* aligned_malloc_f(size_t n) { return (float*)std::malloc(n * sizeof(float)); }
static inline void   aligned_free_f(float* p)  { std::free(p); }

/************  索引结构  ************/
struct IVFIndex {
    float*    centroids;          // [N_LIST , DIM]
    int**     ivf_lists;          // [N_LIST][list_size]
    int*      list_size;          // [N_LIST]
    float*    pq_codebooks;       // [N_LIST , M , K_PQ , DIM_PER_SUBSPACE]
    uint8_t** pq_codes;           // [N_LIST][list_size * M]
    bool      loaded = false;

    ~IVFIndex() { release(); }
    void release() {
        if (!loaded) return;
        aligned_free_f(centroids);
        aligned_free_f(pq_codebooks);
        delete[] list_size;
        for (int i = 0; i < N_LIST; ++i) {
            delete[] ivf_lists[i];
            aligned_free_f((float*)pq_codes[i]);
        }
        delete[] ivf_lists;
        delete[] pq_codes;
        loaded = false;
    }
};
static IVFIndex g_index;

/************  内积  ************/
static inline float dot(const float* a, const float* b, int d) {
#if defined(__ARM_NEON) || defined(__ARM_NEON__)
    /* ---- NEON：一次处理 4 个 float ---- */
    int i = 0;
    float32x4_t acc = vdupq_n_f32(0.f);

    for (; i + 3 < d; i += 4) {
        float32x4_t av = vld1q_f32(a + i);   // 加载 4 个 a
        float32x4_t bv = vld1q_f32(b + i);   // 加载 4 个 b
        acc = vmlaq_f32(acc, av, bv);        // acc += av * bv
    }

    /* 把向量累加成标量 */
    float32x2_t sum2 = vadd_f32(vget_low_f32(acc), vget_high_f32(acc));
    float result     = vget_lane_f32(sum2, 0) + vget_lane_f32(sum2, 1);

    return result;

#else
    /* ---- 标量退化实现 ---- */
    float res = 0.f;
    for (int i = 0; i < d; ++i) res += a[i] * b[i];
    return res;
#endif
}

/**************************************************************
 *                    2. 读取索引（单线程）
 *************************************************************/
static bool load_index_from_disk(const std::string& path = "files") {
    if (g_index.loaded) return true;

    std::ifstream fin(path + "/centroids.bin", std::ios::binary);
    if (!fin) { std::cerr << "open centroids fail\n"; return false; }
    int nlist, dim; fin.read((char*)&nlist,4); fin.read((char*)&dim,4);
    assert(nlist==N_LIST && dim==DIM);
    g_index.centroids = aligned_malloc_f((size_t)N_LIST * DIM);
    fin.read((char*)g_index.centroids, sizeof(float)*N_LIST*DIM);
    fin.close();

    fin.open(path + "/ivf_lists.bin", std::ios::binary);
    if (!fin) { std::cerr << "open ivf_lists fail\n"; return false; }
    g_index.ivf_lists = new int*[N_LIST];
    g_index.list_size = new int[N_LIST];
    for (int i=0;i<N_LIST;++i){
        fin.read((char*)&g_index.list_size[i],4);
        if (g_index.list_size[i]){
            g_index.ivf_lists[i]=new int[g_index.list_size[i]];
            fin.read((char*)g_index.ivf_lists[i], 4LL*g_index.list_size[i]);
        }else g_index.ivf_lists[i]=nullptr;
    }
    fin.close();

    fin.open(path + "/pq_codebooks.bin", std::ios::binary);
    int n1,m,kpq,subd;
    fin.read((char*)&n1,4); fin.read((char*)&m,4);
    fin.read((char*)&kpq,4); fin.read((char*)&subd,4);
    assert(n1==N_LIST&&m==M&&kpq==K_PQ&&subd==DIM_PER_SUBSPACE);
    size_t cb_sz=(size_t)N_LIST*M*K_PQ*DIM_PER_SUBSPACE;
    g_index.pq_codebooks=aligned_malloc_f(cb_sz);
    fin.read((char*)g_index.pq_codebooks, cb_sz*sizeof(float));
    fin.close();

    fin.open(path + "/pq_codes.bin", std::ios::binary);
    g_index.pq_codes=new uint8_t*[N_LIST];
    for(int i=0;i<N_LIST;++i){
        int cnt; fin.read((char*)&cnt,4);
        if(cnt){
            g_index.pq_codes[i]=(uint8_t*)aligned_malloc_f(cnt*M);
            fin.read((char*)g_index.pq_codes[i], cnt*M);
        }else g_index.pq_codes[i]=nullptr;
    }
    fin.close();
    g_index.loaded=true;
    return true;
}

/**************************************************************
 *                3. 多线程 coarseSearch
 *************************************************************/
static void coarseSearch_mt(const float* q, int nprobe,
                            float* centroid_scores, int* best_ids)
{
    /* 3.1 计算 q·c_i (并发) */
    int chunk = (N_LIST + THREAD_NUM - 1) / THREAD_NUM;
    std::atomic<int> cnt{0};

    for (int t = 0; t < THREAD_NUM; ++t) {
        int beg = t * chunk;
        int end = std::min(N_LIST, beg + chunk);
        if (beg >= end) { cnt.fetch_add(1); continue; }

        getPool().enqueue([=, &cnt, q, centroid_scores, best_ids]() {
            for (int i = beg; i < end; ++i) {
                centroid_scores[i] = dot(q, g_index.centroids + (size_t)i * DIM, DIM);
                best_ids[i]        = i;
            }
            cnt.fetch_add(1, std::memory_order_relaxed);
        });
    }

    /* 3.2 等待所有线程完成 */
    while (cnt.load(std::memory_order_relaxed) != THREAD_NUM) sched_yield();

    /* 3.3 主线程做部分排序挑出 nprobe id */
    std::partial_sort(best_ids, best_ids + nprobe, best_ids + N_LIST,
                      [&](int a,int b){ return centroid_scores[a] > centroid_scores[b]; });
}

/**************************************************************
 *                4. 多线程 fineSearch
 *************************************************************/
using Pair = std::pair<float,uint32_t>;        // first=dist, second=id

static void fineSearch_mt(const float* q,
                          const float* centroid_scores,
                          const int*   probe_ids,
                          int nprobe, int top_p,
                          std::vector<Pair>& out)
{
    /* 把 nprobe 个 list 均匀分给 THREAD_NUM 线程 */
    int chunk = (nprobe + THREAD_NUM - 1) / THREAD_NUM;
    std::vector<std::vector<Pair>> local_vec(THREAD_NUM);
    std::atomic<int> done{0};

    for (int t = 0; t < THREAD_NUM; ++t) {
        int beg = t * chunk;
        int end = std::min(nprobe, beg + chunk);
        if (beg >= end) { done.fetch_add(1); continue; }

        getPool().enqueue([=, &local_vec, &done, q, centroid_scores, probe_ids]() {
            auto& vec = local_vec[t];
            float dist_tb[M*K_PQ];

            for (int p = beg; p < end; ++p) {
                int cid  = probe_ids[p];
                float qc = centroid_scores[cid];

                /* --- 构表 --- */
                const float* cb_base = g_index.pq_codebooks + (size_t)cid*M*K_PQ*DIM_PER_SUBSPACE;
                for (int m = 0; m < M; ++m){
                    const float* qsub = q + m*DIM_PER_SUBSPACE;
                    for (int k = 0; k < K_PQ; ++k){
                        const float* ckw = cb_base + (size_t)m*K_PQ*DIM_PER_SUBSPACE + k*DIM_PER_SUBSPACE;
                        dist_tb[m*K_PQ+k] = dot(qsub, ckw, DIM_PER_SUBSPACE);
                    }
                }
                /* --- 遍历 list --- */
                int  L = g_index.list_size[cid];
                const uint8_t* codes = g_index.pq_codes[cid];
                const int*     ids   = g_index.ivf_lists[cid];
                for(int i=0;i<L;++i){
                    float score = qc;
                    const uint8_t* code = codes + i*M;
                    for(int m=0;m<M;++m) score += dist_tb[m*K_PQ + code[m]];
                    vec.emplace_back(-score, ids[i]);
                }
            }
            done.fetch_add(1, std::memory_order_relaxed);
        });
    }

    /* 等所有子任务结束 */
    while(done.load(std::memory_order_relaxed) != THREAD_NUM) sched_yield();

    /* merge 所有局部向量 */
    size_t tot = 0;
    for (auto& v : local_vec) tot += v.size();
    out.reserve(tot);
    for (auto& v : local_vec) {
        out.insert(out.end(),
                   std::make_move_iterator(v.begin()),
                   std::make_move_iterator(v.end()));
    }

    /* 保留 top_p */
    if ((int)out.size() > top_p){
        std::nth_element(out.begin(), out.begin()+top_p, out.end(),
                         [](const Pair&a,const Pair&b){ return a.first < b.first; });
        out.resize(top_p);
    }
}

/**************************************************************
 *                5. 对外主函数（接口不变）
 *************************************************************/
static std::priority_queue<Pair>
annSearch(float* base, float* query,
          size_t base_number, size_t vecdim,
          size_t top_p, size_t top_k, size_t nprobe)
{
    if (!load_index_from_disk()) return {};

    /* 1. coarse (多线程) */
    std::vector<float> centroid_scores(N_LIST);
    std::vector<int>   probe_ids(N_LIST);
    coarseSearch_mt(query, (int)nprobe,
                    centroid_scores.data(), probe_ids.data());

    /* 2. fine (多线程) */
    std::vector<Pair> candidates;
    fineSearch_mt(query, centroid_scores.data(), probe_ids.data(),
                  (int)nprobe, (int)top_p, candidates);

    /* 3. 精确重排（单线程，小数据量） */
    std::priority_queue<Pair> heap;
    for (const auto& pr : candidates){
        uint32_t idx = pr.second;
        float dotv = dot(query, base + (size_t)idx*vecdim, vecdim);
        float dist = 1.f - dotv;
        if (heap.size() < top_k) heap.emplace(dist, idx);
        else if (dist < heap.top().first){ heap.pop(); heap.emplace(dist, idx); }
    }
    return heap;
}

#endif /* IVF_PQ_SEARCH_H */